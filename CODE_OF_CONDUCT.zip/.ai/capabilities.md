# Capabilities schema (documentation)

Machine-readable JSON lives at [`capabilities.json`](capabilities.json). If that file is missing in your checkout, copy the block below into `capabilities.json`.

**This is not live platform state** - JodKit has no runtime capability registry during Architecture / Research.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$comment": "JodKit documentation artifact - NOT live platform state.",
  "documentationOnly": true,
  "platformPhase": "architecture-research",
  "description": "Example capability IDs and provider declarations for AI agents planning JodKit extensions.",
  "capabilityIds": [
    "payment",
    "shipping",
    "tax",
    "email",
    "sms",
    "storage",
    "search",
    "ai",
    "analytics",
    "authentication",
    "cdn",
    "image-processing",
    "notifications"
  ],
  "exampleProviders": [
    {
      "example": true,
      "pluginId": "razorpay",
      "implements": ["payment"],
      "providerContract": "PaymentProvider"
    },
    {
      "example": true,
      "pluginId": "shiprocket",
      "implements": ["shipping"],
      "providerContract": "ShippingProvider"
    },
    {
      "example": true,
      "pluginId": "s3-storage",
      "implements": ["storage"],
      "providerContract": "StorageProvider"
    }
  ],
  "exampleProjectManifest": {
    "example": true,
    "description": "Illustrative per-site manifest - future CLI may generate this.",
    "platformVersion": "1.0",
    "modules": ["cms", "auth", "media", "commerce", "seo"],
    "plugins": ["reviews", "razorpay"],
    "theme": "storefront",
    "database": "postgresql"
  },
  "exampleModuleManifest": {
    "example": true,
    "name": "ecommerce",
    "version": "1.0.0",
    "dependencies": ["core", "users", "media"],
    "optionalDependencies": ["forms", "seo"],
    "capabilities": [
      "products",
      "cart",
      "checkout",
      "orders",
      "payments",
      "inventory"
    ]
  }
}
```

See [docs/providers.md](../docs/providers.md) and [Foundation section 10](../docs/project-foundation-v0.1.md#10-capability-system).
